chrome.tabs.onUpdated.addListener((s,d,t)=>{if(d.title&&t.url&&t.url.includes("chatgpt.com")){let e=t.url.split("/").pop();e||(e="home"),e&&chrome.tabs.sendMessage(s,{chatId:e})}});
